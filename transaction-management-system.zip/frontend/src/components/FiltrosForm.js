import React, { useState, useEffect } from 'react';
import {
  Paper,
  TextField,
  Button,
  Box,
  Typography,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';

const FiltrosForm = ({ filtros, onAplicarFiltros, onLimpiarFiltros }) => {
  const [formData, setFormData] = useState({
    nombre: '',
    fecha: null,
    estado: '',
  });

  useEffect(() => {
    setFormData({
      nombre: filtros.nombre || '',
      fecha: filtros.fecha ? dayjs(filtros.fecha) : null,
      estado: filtros.estado || '',
    });
  }, [filtros]);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const filtrosAplicados = {};
    if (formData.nombre.trim()) filtrosAplicados.nombre = formData.nombre.trim();
    if (formData.fecha) filtrosAplicados.fecha = formData.fecha.format('YYYY-MM-DD');
    if (formData.estado) filtrosAplicados.estado = formData.estado;
    
    onAplicarFiltros(filtrosAplicados);
  };

  const handleLimpiar = () => {
    setFormData({
      nombre: '',
      fecha: null,
      estado: '',
    });
    onLimpiarFiltros();
  };

  return (
    <Paper elevation={3} sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Filtros de Búsqueda
      </Typography>
      
      <Box component="form" onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={3}>
            <TextField
              fullWidth
              label="Nombre"
              value={formData.nombre}
              onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
              placeholder="Buscar por nombre..."
            />
          </Grid>
          
          <Grid item xs={12} md={3}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                label="Fecha"
                value={formData.fecha}
                onChange={(newValue) => setFormData({ ...formData, fecha: newValue })}
                renderInput={(params) => <TextField {...params} fullWidth />}
              />
            </LocalizationProvider>
          </Grid>
          
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Estado</InputLabel>
              <Select
                value={formData.estado}
                label="Estado"
                onChange={(e) => setFormData({ ...formData, estado: e.target.value })}
              >
                <MenuItem value="">Todos</MenuItem>
                <MenuItem value="PENDIENTE">Pendiente</MenuItem>
                <MenuItem value="PAGADO">Pagado</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={3}>
            <Box sx={{ display: 'flex', gap: 1, height: '100%', alignItems: 'center' }}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
              >
                Aplicar Filtros
              </Button>
              <Button
                variant="outlined"
                onClick={handleLimpiar}
                fullWidth
              >
                Limpiar
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Paper>
  );
};

export default FiltrosForm; 