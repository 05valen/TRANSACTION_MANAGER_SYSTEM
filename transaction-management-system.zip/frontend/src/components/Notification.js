import React from 'react';
import { Snackbar, Alert, AlertTitle } from '@mui/material';
import { CheckCircle, Error, Info, Warning } from '@mui/icons-material';

/**
 * Component for displaying elegant notifications using Material-UI Snackbar.
 * 
 * @component
 * @param {Object} props - Component props
 * @param {boolean} props.open - Whether the notification is visible
 * @param {string} props.message - Notification message
 * @param {string} props.title - Notification title (optional)
 * @param {string} props.severity - Notification type: 'success', 'error', 'warning', 'info'
 * @param {Function} props.onClose - Callback when notification is closed
 * @param {number} props.autoHideDuration - Duration in milliseconds (default: 4000)
 * 
 * @example
 * <Notification
 *   open={showNotification}
 *   message="Transacción creada exitosamente"
 *   severity="success"
 *   onClose={() => setShowNotification(false)}
 * />
 */
const Notification = ({ 
  open, 
  message, 
  title, 
  severity = 'info', 
  onClose, 
  autoHideDuration = 4000 
}) => {
  const getIcon = () => {
    switch (severity) {
      case 'success':
        return <CheckCircle />;
      case 'error':
        return <Error />;
      case 'warning':
        return <Warning />;
      case 'info':
        return <Info />;
      default:
        return <Info />;
    }
  };

  return (
    <Snackbar
      open={open}
      autoHideDuration={autoHideDuration}
      onClose={onClose}
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      sx={{ mt: 8 }} // Margin top to avoid header overlap
    >
      <Alert
        onClose={onClose}
        severity={severity}
        icon={getIcon()}
        variant="filled"
        sx={{
          minWidth: '300px',
          '& .MuiAlert-message': {
            fontSize: '0.95rem',
          },
          '& .MuiAlertTitle-root': {
            fontSize: '1rem',
            fontWeight: 'bold',
          }
        }}
      >
        {title && <AlertTitle>{title}</AlertTitle>}
        {message}
      </Alert>
    </Snackbar>
  );
};

export default Notification; 