import React, { useState } from 'react';
import {
  Paper,
  TextField,
  Button,
  Box,
  Typography,
  Grid,
} from '@mui/material';

const PagoForm = ({ onPagar }) => {
  const [monto, setMonto] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!monto || parseFloat(monto) <= 0) {
      alert('Por favor ingrese un monto válido');
      return;
    }

    if (window.confirm(`¿Está seguro de que desea realizar un pago por ${monto}?`)) {
      onPagar(parseFloat(monto));
      setMonto('');
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Realizar Pago
      </Typography>
      
      <Box component="form" onSubmit={handleSubmit}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="Monto a Pagar"
              type="number"
              value={monto}
              onChange={(e) => setMonto(e.target.value)}
              inputProps={{ min: "0.01", step: "0.01" }}
              placeholder="Ingrese el monto a pagar..."
              required
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Button
              type="submit"
              variant="contained"
              color="success"
              size="large"
              fullWidth
            >
              Realizar Pago
            </Button>
          </Grid>
        </Grid>
        
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" color="text.secondary">
            <strong>Nota:</strong> El sistema pagará las transacciones en orden cronológico (más antigua primero) 
            y solo si el monto cubre completamente cada transacción.
          </Typography>
        </Box>
      </Box>
    </Paper>
  );
};

export default PagoForm; 