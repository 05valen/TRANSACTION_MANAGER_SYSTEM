import React, { useState, useEffect } from 'react';
import {
  Paper,
  TextField,
  Button,
  Box,
  Typography,
  Grid,
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';

/**
 * Form component for creating and editing transactions.
 * 
 * This component provides a form interface for:
 * - Creating new transactions with validation
 * - Editing existing transactions (only if not paid)
 * - Real-time form validation
 * - Date picker integration
 * 
 * @component
 * @param {Object} props - Component props
 * @param {Function} props.onSubmit - Callback for form submission (create mode)
 * @param {Object|null} props.editingTransaccion - Transaction being edited (null for create mode)
 * @param {Function} props.onEdit - Callback for form submission (edit mode)
 * @param {Function} props.onCancel - Callback for canceling edit mode
 * @param {Function} props.onShowNotification - Callback to show notifications (optional)
 * 
 * @example
 * ```jsx
 * // Create mode
 * <TransaccionForm onSubmit={handleCreate} onShowNotification={showNotification} />
 * 
 * // Edit mode
 * <TransaccionForm 
 *   editingTransaccion={transaction}
 *   onEdit={handleEdit}
 *   onCancel={handleCancel}
 *   onShowNotification={showNotification}
 * />
 * ```
 */
const TransaccionForm = ({ onSubmit, editingTransaccion, onEdit, onCancel, onShowNotification }) => {
  /**
   * Form data state.
   * @type {[Object, Function]}
   */
  const [formData, setFormData] = useState({
    nombre: '',
    fecha: dayjs(),
    valor: '',
  });

  /**
   * Updates form data when editing transaction changes.
   * Populates form fields with existing transaction data.
   */
  useEffect(() => {
    if (editingTransaccion) {
      setFormData({
        nombre: editingTransaccion.nombre,
        fecha: dayjs(editingTransaccion.fecha),
        valor: editingTransaccion.valor.toString(),
      });
    } else {
      setFormData({
        nombre: '',
        fecha: dayjs(),
        valor: '',
      });
    }
  }, [editingTransaccion]);

  /**
   * Handles form submission for both create and edit modes.
   * Validates form data before submission.
   * 
   * @param {Event} e - Form submission event
   */
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.nombre.trim() || !formData.valor) {
      onShowNotification('Por favor complete todos los campos');
      return;
    }

    const transaccionData = {
      nombre: formData.nombre.trim(),
      fecha: formData.fecha.format('YYYY-MM-DD'),
      valor: parseFloat(formData.valor),
    };

    console.log('Form submitted:', { editingTransaccion, transaccionData });

    if (editingTransaccion) {
      console.log('Calling onEdit with:', editingTransaccion.id, transaccionData);
      onEdit(editingTransaccion.id, transaccionData);
    } else {
      console.log('Calling onSubmit with:', transaccionData);
      onSubmit(transaccionData);
      setFormData({
        nombre: '',
        fecha: dayjs(),
        valor: '',
      });
    }
  };

  /**
   * Handles canceling edit mode and resets form.
   */
  const handleCancel = () => {
    setFormData({
      nombre: '',
      fecha: dayjs(),
      valor: '',
    });
    onCancel();
  };

  return (
    <Paper elevation={3} sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        {editingTransaccion ? 'Editar Transacción' : 'Nueva Transacción'}
      </Typography>
      
      <Box component="form" onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Nombre"
              value={formData.nombre}
              onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
              required
            />
          </Grid>
          
          <Grid item xs={12} md={4}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                label="Fecha"
                value={formData.fecha}
                onChange={(newValue) => setFormData({ ...formData, fecha: newValue })}
                renderInput={(params) => <TextField {...params} fullWidth required />}
              />
            </LocalizationProvider>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Valor"
              type="number"
              value={formData.valor}
              onChange={(e) => setFormData({ ...formData, valor: e.target.value })}
              inputProps={{ min: "0.01", step: "0.01" }}
              required
            />
          </Grid>
        </Grid>
        
        <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
          >
            {editingTransaccion ? 'Actualizar' : 'Crear'}
          </Button>
          
          {editingTransaccion && (
            <Button
              variant="outlined"
              onClick={handleCancel}
            >
              Cancelar
            </Button>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default TransaccionForm; 