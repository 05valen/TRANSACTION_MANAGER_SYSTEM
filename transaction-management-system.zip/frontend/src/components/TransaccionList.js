import React from 'react';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
  Typography,
  Box,
  CircularProgress,
} from '@mui/material';
import { Edit, Delete } from '@mui/icons-material';
import dayjs from 'dayjs';

const TransaccionList = ({ transacciones, loading, onEdit, onDelete }) => {
  const getEstadoColor = (estado) => {
    switch (estado) {
      case 'PENDIENTE':
        return 'warning';
      case 'PAGADO':
        return 'success';
      default:
        return 'default';
    }
  };

  const formatCurrency = (valor) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
    }).format(valor);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  if (transacciones.length === 0) {
    return (
      <Paper elevation={3} sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Lista de Transacciones
        </Typography>
        <Typography variant="body1" color="text.secondary">
          No hay transacciones para mostrar.
        </Typography>
      </Paper>
    );
  }

  return (
    <Paper elevation={3}>
      <Box sx={{ p: 2 }}>
        <Typography variant="h6" gutterBottom>
          Lista de Transacciones ({transacciones.length})
        </Typography>
      </Box>
      
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Nombre</TableCell>
              <TableCell>Fecha</TableCell>
              <TableCell>Valor</TableCell>
              <TableCell>Estado</TableCell>
              <TableCell>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {transacciones.map((transaccion) => (
              <TableRow key={transaccion.id}>
                <TableCell>{transaccion.id}</TableCell>
                <TableCell>{transaccion.nombre}</TableCell>
                <TableCell>
                  {dayjs(transaccion.fecha).format('DD/MM/YYYY')}
                </TableCell>
                <TableCell>{formatCurrency(transaccion.valor)}</TableCell>
                <TableCell>
                  <Chip
                    label={transaccion.estado}
                    color={getEstadoColor(transaccion.estado)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  {transaccion.estado === 'PENDIENTE' && (
                    <>
                      <IconButton
                        size="small"
                        onClick={() => onEdit(transaccion)}
                        color="primary"
                      >
                        <Edit />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() => onDelete(transaccion.id)}
                        color="error"
                      >
                        <Delete />
                      </IconButton>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default TransaccionList; 