import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  CssBaseline,
  ThemeProvider,
  createTheme,
} from '@mui/material';
import TransaccionList from './components/TransaccionList';
import TransaccionForm from './components/TransaccionForm';
import PagoForm from './components/PagoForm';
import FiltrosForm from './components/FiltrosForm';
import Notification from './components/Notification';
import { transaccionService } from './services/api';

/**
 * Material-UI theme configuration for the application.
 * Provides consistent styling and color scheme.
 */
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

/**
 * Main application component for the Transaction Management System.
 * 
 * This component orchestrates the entire application, managing:
 * - Transaction data state and API calls
 * - Form submissions and data validation
 * - Filtering and search functionality
 * - Payment processing
 * - Error handling and user feedback
 * 
 * @component
 * @example
 * ```jsx
 * <App />
 * ```
 */
function App() {
  /** @type {[Array<Object>, Function]} List of transactions and setter function */
  const [transacciones, setTransacciones] = useState([]);
  
  /** @type {[boolean, Function]} Loading state and setter function */
  const [loading, setLoading] = useState(false);
  
  /** @type {[Object, Function]} Current filter criteria and setter function */
  const [filtros, setFiltros] = useState({});
  
  /** @type {[Object|null, Function]} Currently editing transaction and setter function */
  const [editingTransaccion, setEditingTransaccion] = useState(null);

  /** @type {[Object, Function]} Notification state and setter function */
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    title: '',
    severity: 'info'
  });

  /**
   * Loads transactions from the API with optional filters.
   * 
   * @param {Object} filtrosAplicados - Filter criteria to apply
   * @param {string} [filtrosAplicados.nombre] - Name filter
   * @param {string} [filtrosAplicados.fecha] - Date filter
   * @param {string} [filtrosAplicados.estado] - State filter
   * @returns {Promise<void>}
   */
  const cargarTransacciones = async (filtrosAplicados = {}) => {
    setLoading(true);
    try {
      const response = await transaccionService.getTransacciones(filtrosAplicados);
      setTransacciones(response.data);
    } catch (error) {
      console.error('Error al cargar transacciones:', error);
      alert('Error al cargar las transacciones');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Loads transactions on component mount.
   */
  useEffect(() => {
    cargarTransacciones();
  }, []);

  /**
   * Handles creation of a new transaction.
   * 
   * @param {Object} transaccion - Transaction data to create
   * @param {string} transaccion.nombre - Transaction name
   * @param {string} transaccion.fecha - Transaction date
   * @param {number} transaccion.valor - Transaction amount
   * @returns {Promise<void>}
   */
  const handleCrearTransaccion = async (transaccion) => {
    try {
      console.log('Attempting to create transaction:', transaccion);
      const response = await transaccionService.createTransaccion(transaccion);
      console.log('Transaction created successfully:', response.data);
      await cargarTransacciones(filtros);
      showNotification('Transacción creada exitosamente', 'success', 'Éxito');
    } catch (error) {
      console.error('Error al crear transacción:', error);
      let errorMessage = 'Error al crear la transacción';
      
      if (error.response) {
        // Error de respuesta del servidor
        if (error.response.status === 400) {
          errorMessage = 'Datos inválidos: ' + (error.response.data?.message || 'Verifique los campos');
        } else if (error.response.status === 500) {
          errorMessage = 'Error interno del servidor';
        } else {
          errorMessage = `Error ${error.response.status}: ${error.response.data?.message || 'Error desconocido'}`;
        }
      } else if (error.request) {
        // Error de red
        errorMessage = 'Error de conexión: No se pudo conectar con el servidor';
      } else {
        // Otro tipo de error
        errorMessage = error.message || 'Error desconocido';
      }
      
      showNotification(errorMessage, 'error', 'Error');
    }
  };

  /**
   * Handles updating an existing transaction.
   * 
   * @param {number} id - Transaction ID
   * @param {Object} transaccion - Updated transaction data
   * @returns {Promise<void>}
   */
  const handleEditarTransaccion = async (id, transaccion) => {
    try {
      console.log('Attempting to update transaction:', { id, transaccion });
      const response = await transaccionService.updateTransaccion(id, transaccion);
      console.log('Transaction updated successfully:', response.data);
      await cargarTransacciones(filtros);
      setEditingTransaccion(null);
      showNotification('Transacción actualizada exitosamente', 'success', 'Éxito');
    } catch (error) {
      console.error('Error al actualizar transacción:', error);
      let errorMessage = 'Error al actualizar la transacción';
      
      if (error.response) {
        // Error de respuesta del servidor
        if (error.response.status === 400) {
          errorMessage = 'Datos inválidos: ' + (error.response.data?.message || 'Verifique los campos');
        } else if (error.response.status === 404) {
          errorMessage = 'Transacción no encontrada';
        } else if (error.response.status === 500) {
          errorMessage = 'Error interno del servidor';
        } else {
          errorMessage = `Error ${error.response.status}: ${error.response.data?.message || 'Error desconocido'}`;
        }
      } else if (error.request) {
        // Error de red
        errorMessage = 'Error de conexión: No se pudo conectar con el servidor';
      } else {
        // Otro tipo de error
        errorMessage = error.message || 'Error desconocido';
      }
      
      showNotification(errorMessage, 'error', 'Error');
    }
  };

  /**
   * Handles deletion of a transaction.
   * 
   * @param {number} id - Transaction ID to delete
   * @returns {Promise<void>}
   */
  const handleEliminarTransaccion = async (id) => {
    if (window.confirm('¿Está seguro de que desea eliminar esta transacción?')) {
      try {
        await transaccionService.deleteTransaccion(id);
        cargarTransacciones(filtros);
        showNotification('Transacción eliminada exitosamente', 'success', 'Éxito');
      } catch (error) {
        console.error('Error al eliminar transacción:', error);
        showNotification('Error al eliminar la transacción', 'error', 'Error');
      }
    }
  };

  /**
   * Handles payment processing.
   * 
   * @param {number} monto - Amount to pay
   * @returns {Promise<void>}
   */
  const handleRealizarPago = async (monto) => {
    try {
      console.log('Attempting to make payment:', monto);
      const response = await transaccionService.realizarPago(monto);
      console.log('Payment response:', response.data);
      
      // Recargar las transacciones después del pago
      console.log('Reloading transactions after payment...');
      await cargarTransacciones(filtros);
      console.log('Transactions reloaded successfully');
      
      showNotification(response.data, 'success', 'Pago Realizado');
    } catch (error) {
      console.error('Error al realizar pago:', error);
      let errorMessage = 'Error al realizar el pago';
      
      if (error.response) {
        // Error de respuesta del servidor
        if (error.response.status === 400) {
          errorMessage = 'Monto inválido: ' + (error.response.data?.message || 'Verifique el monto');
        } else if (error.response.status === 404) {
          errorMessage = 'No hay transacciones pendientes para pagar';
        } else if (error.response.status === 500) {
          errorMessage = 'Error interno del servidor';
        } else {
          errorMessage = `Error ${error.response.status}: ${error.response.data?.message || 'Error desconocido'}`;
        }
      } else if (error.request) {
        // Error de red
        errorMessage = 'Error de conexión: No se pudo conectar con el servidor';
      } else {
        // Otro tipo de error
        errorMessage = error.message || 'Error desconocido';
      }
      
      showNotification(errorMessage, 'error', 'Error');
    }
  };

  /**
   * Applies filters to the transaction list.
   * 
   * @param {Object} nuevosFiltros - New filter criteria
   * @returns {Promise<void>}
   */
  const handleAplicarFiltros = (nuevosFiltros) => {
    setFiltros(nuevosFiltros);
    cargarTransacciones(nuevosFiltros);
  };

  /**
   * Clears all filters and loads all transactions.
   * 
   * @returns {Promise<void>}
   */
  const handleLimpiarFiltros = () => {
    setFiltros({});
    cargarTransacciones({});
  };

  /**
   * Shows a notification with the specified parameters.
   * 
   * @param {string} message - Notification message
   * @param {string} severity - Notification type: 'success', 'error', 'warning', 'info'
   * @param {string} title - Notification title (optional)
   */
  const showNotification = (message, severity = 'info', title = '') => {
    setNotification({
      open: true,
      message,
      title,
      severity
    });
  };

  /**
   * Closes the current notification.
   */
  const closeNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container maxWidth="lg">
        <Box sx={{ my: 4 }}>
          <Typography variant="h3" component="h1" gutterBottom align="center">
            Sistema de Registro de Transacciones
          </Typography>

          <Box sx={{ mb: 4 }}>
            <TransaccionForm
              onSubmit={handleCrearTransaccion}
              editingTransaccion={editingTransaccion}
              onEdit={handleEditarTransaccion}
              onCancel={() => setEditingTransaccion(null)}
              onShowNotification={(message) => showNotification(message, 'warning', 'Validación')}
            />
          </Box>

          <Box sx={{ mb: 4 }}>
            <PagoForm onPagar={handleRealizarPago} />
          </Box>

          <Box sx={{ mb: 4 }}>
            <FiltrosForm
              filtros={filtros}
              onAplicarFiltros={handleAplicarFiltros}
              onLimpiarFiltros={handleLimpiarFiltros}
            />
          </Box>

          <TransaccionList
            transacciones={transacciones}
            loading={loading}
            onEdit={setEditingTransaccion}
            onDelete={handleEliminarTransaccion}
          />
        </Box>
      </Container>
      
      {/* Elegant notification component */}
      <Notification
        open={notification.open}
        message={notification.message}
        title={notification.title}
        severity={notification.severity}
        onClose={closeNotification}
      />
    </ThemeProvider>
  );
}

export default App;
