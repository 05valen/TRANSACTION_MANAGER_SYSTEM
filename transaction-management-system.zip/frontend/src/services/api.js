import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

/**
 * Axios instance configured for the backend API.
 * @type {import('axios').AxiosInstance}
 */
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 segundos de timeout
});

// Interceptor para logging de requests
api.interceptors.request.use(
  (config) => {
    console.log('API Request:', config.method?.toUpperCase(), config.url, config.data);
    return config;
  },
  (error) => {
    console.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// Interceptor para logging de responses
api.interceptors.response.use(
  (response) => {
    console.log('API Response:', response.status, response.data);
    return response;
  },
  (error) => {
    console.error('API Response Error:', error.response?.status, error.response?.data, error.message);
    return Promise.reject(error);
  }
);

/**
 * Service for handling all transaction-related API calls.
 * Provides methods for CRUD operations, filtering, and payment processing.
 */
export const transaccionService = {
  /**
   * Retrieves a list of transactions with optional filters.
   * 
   * @param {Object} filtros - Filter criteria
   * @param {string} [filtros.nombre] - Name filter (partial match)
   * @param {string} [filtros.fecha] - Date filter (YYYY-MM-DD format)
   * @param {string} [filtros.estado] - State filter ('PENDIENTE' or 'PAGADO')
   * @returns {Promise<import('axios').AxiosResponse<Array<import('../types/Transaccion').Transaccion>>>} Promise resolving to filtered transactions
   * @example
   * // Get all transactions
   * const response = await transaccionService.getTransacciones();
   * 
   * // Get pending transactions with name filter
   * const response = await transaccionService.getTransacciones({
   *   nombre: 'payment',
   *   estado: 'PENDIENTE'
   * });
   */
  getTransacciones: (filtros = {}) => {
    const params = new URLSearchParams();
    if (filtros.nombre) params.append('nombre', filtros.nombre);
    if (filtros.fecha) params.append('fecha', filtros.fecha);
    if (filtros.estado) params.append('estado', filtros.estado);
    
    return api.get(`/transacciones?${params.toString()}`);
  },

  /**
   * Retrieves a single transaction by its ID.
   * 
   * @param {number} id - Transaction ID
   * @returns {Promise<import('axios').AxiosResponse<import('../types/Transaccion').Transaccion>>} Promise resolving to the transaction
   * @throws {Error} When transaction is not found
   */
  getTransaccion: (id) => {
    return api.get(`/transacciones/${id}`);
  },

  /**
   * Creates a new transaction.
   * 
   * @param {Object} transaccion - Transaction data
   * @param {string} transaccion.nombre - Transaction name/description
   * @param {string} transaccion.fecha - Transaction date (YYYY-MM-DD format)
   * @param {number} transaccion.valor - Transaction amount (positive number)
   * @returns {Promise<import('axios').AxiosResponse<import('../types/Transaccion').Transaccion>>} Promise resolving to the created transaction
   * @throws {Error} When validation fails or server error occurs
   */
  createTransaccion: (transaccion) => {
    console.log('Creating transaction:', transaccion);
    return api.post('/transacciones', transaccion);
  },

  /**
   * Updates an existing transaction.
   * Only allowed if the transaction is not paid.
   * 
   * @param {number} id - Transaction ID
   * @param {Object} transaccion - Updated transaction data
   * @param {string} transaccion.nombre - Transaction name/description
   * @param {string} transaccion.fecha - Transaction date (YYYY-MM-DD format)
   * @param {number} transaccion.valor - Transaction amount (positive number)
   * @returns {Promise<import('axios').AxiosResponse<import('../types/Transaccion').Transaccion>>} Promise resolving to the updated transaction
   * @throws {Error} When transaction is not found, is already paid, or validation fails
   */
  updateTransaccion: (id, transaccion) => {
    console.log('API: Updating transaction with ID:', id, 'Data:', transaccion);
    return api.put(`/transacciones/${id}`, transaccion);
  },

  /**
   * Deletes a transaction.
   * Only allowed if the transaction is not paid.
   * 
   * @param {number} id - Transaction ID
   * @returns {Promise<import('axios').AxiosResponse<void>>} Promise resolving when transaction is deleted
   * @throws {Error} When transaction is not found or is already paid
   */
  deleteTransaccion: (id) => {
    return api.delete(`/transacciones/${id}`);
  },

  /**
   * Processes a payment, marking transactions as paid in chronological order.
   * Only pays transactions that can be fully covered by the amount.
   * 
   * @param {number} monto - Amount to pay (positive number)
   * @returns {Promise<import('axios').AxiosResponse<string>>} Promise resolving to payment result message
   * @throws {Error} When payment processing fails
   * @example
   * const response = await transaccionService.realizarPago(100.50);
   * console.log(response.data); // "Pago realizado. Monto restante: 25.00"
   */
  realizarPago: (monto) => {
    console.log('API: Making payment for amount:', monto);
    return api.post(`/transacciones/pagar?monto=${monto}`);
  },
};

export default api; 