# Frontend - Sistema de Registro de Transacciones

Interfaz de usuario desarrollada en React para el Sistema de Registro de Transacciones.

## Tecnologías Utilizadas

- **React 19** - Biblioteca de JavaScript para interfaces de usuario
- **Material-UI (MUI)** - Framework de componentes de React
- **Axios** - Cliente HTTP para realizar peticiones a la API
- **Day.js** - Biblioteca para manejo de fechas
- **npm** - Gestor de paquetes de Node.js

## Estructura del Proyecto

```
frontend/
├── public/
│   ├── index.html
│   └── favicon.ico
├── src/
│   ├── components/              # Componentes de React
│   │   ├── TransaccionForm.js   # Formulario para crear/editar transacciones
│   │   ├── TransaccionList.js   # Lista de transacciones con tabla
│   │   ├── FiltrosForm.js       # Formulario de filtros de búsqueda
│   │   └── PagoForm.js          # Formulario para realizar pagos
│   ├── services/                # Servicios de API
│   │   └── api.js               # Cliente HTTP y métodos de API
│   ├── App.js                   # Componente principal de la aplicación
│   ├── App.css                  # Estilos del componente principal
│   └── index.js                 # Punto de entrada de la aplicación
├── package.json                 # Dependencias y scripts
└── README.md                    # Este archivo
```

## Instalación y Ejecución

### Prerrequisitos
- Node.js 16 o superior
- npm o yarn

### Instalación

1. **Navegar al directorio del frontend:**
```bash
cd frontend
```

2. **Instalar dependencias:**
```bash
npm install
```

### Ejecución

**Modo desarrollo:**
```bash
npm start
```

La aplicación se abrirá automáticamente en `http://localhost:3000`

**Modo producción:**
```bash
npm run build
```

### Pruebas

```bash
npm test
```

## Componentes

### TransaccionForm
Formulario para crear y editar transacciones.

**Props:**
- `onSubmit` (Function) - Callback para crear nueva transacción
- `editingTransaccion` (Object|null) - Transacción siendo editada
- `onEdit` (Function) - Callback para actualizar transacción
- `onCancel` (Function) - Callback para cancelar edición

**Características:**
- Validación en tiempo real
- Selector de fecha con DatePicker
- Campos requeridos: nombre, fecha, valor
- Modo creación y edición

### TransaccionList
Tabla que muestra la lista de transacciones.

**Props:**
- `transacciones` (Array) - Lista de transacciones
- `loading` (Boolean) - Estado de carga
- `onEdit` (Function) - Callback para editar transacción
- `onDelete` (Function) - Callback para eliminar transacción

**Características:**
- Tabla responsive con Material-UI
- Estados visuales (PENDIENTE/PAGADO)
- Acciones de editar/eliminar solo para transacciones pendientes
- Formato de moneda colombiana
- Indicador de carga

### FiltrosForm
Formulario para filtrar transacciones.

**Props:**
- `filtros` (Object) - Filtros actuales
- `onAplicarFiltros` (Function) - Callback para aplicar filtros
- `onLimpiarFiltros` (Function) - Callback para limpiar filtros

**Características:**
- Filtro por nombre (búsqueda parcial)
- Filtro por fecha exacta
- Filtro por estado (PENDIENTE/PAGADO/Todos)
- Botones para aplicar y limpiar filtros

### PagoForm
Formulario para realizar pagos.

**Props:**
- `onPagar` (Function) - Callback para realizar pago

**Características:**
- Campo numérico para monto
- Validación de monto positivo
- Confirmación antes de realizar pago
- Información sobre el comportamiento del sistema de pagos

## Servicios de API

### transaccionService

Métodos disponibles:

- `getTransacciones(filtros)` - Obtener lista de transacciones
- `getTransaccion(id)` - Obtener transacción por ID
- `createTransaccion(transaccion)` - Crear nueva transacción
- `updateTransaccion(id, transaccion)` - Actualizar transacción
- `deleteTransaccion(id)` - Eliminar transacción
- `realizarPago(monto)` - Realizar pago

## Configuración

### Proxy
El proyecto está configurado para hacer proxy al backend en `http://localhost:8080`:

```json
{
  "proxy": "http://localhost:8080"
}
```

### Variables de Entorno
Para cambiar la URL del backend, crear un archivo `.env`:

```env
REACT_APP_API_URL=http://localhost:8080/api
```

## Características Técnicas

### Arquitectura
- **Componentes Funcionales** con hooks de React
- **Estado Local** con useState
- **Efectos** con useEffect para operaciones asíncronas
- **Props** para comunicación entre componentes

### UI/UX
- **Material-UI** para componentes consistentes
- **Tema Personalizado** con colores primarios y secundarios
- **Responsive Design** adaptable a diferentes pantallas
- **Feedback Visual** con confirmaciones y alertas
- **Validación en Tiempo Real** en formularios

### Manejo de Errores
- **Try-Catch** en operaciones asíncronas
- **Alertas** para errores de usuario
- **Logging** en consola para debugging
- **Estados de Carga** para mejor UX

### Validaciones
- **Frontend**: Validación en tiempo real en formularios
- **Backend**: Validación de datos con Bean Validation
- **Mensajes de Error** descriptivos para el usuario

## Casos de Uso

### Crear Transacción
1. Llenar formulario con nombre, fecha y valor
2. Hacer clic en "Crear"
3. La transacción aparece en la lista con estado "PENDIENTE"

### Editar Transacción
1. Hacer clic en ícono de editar (solo disponible para transacciones pendientes)
2. Modificar campos en el formulario
3. Hacer clic en "Actualizar"

### Realizar Pago
1. Ingresar monto en el formulario de pago
2. Confirmar la operación
3. El sistema procesa el pago y actualiza la lista

### Filtrar Transacciones
1. Usar filtros de nombre, fecha o estado
2. Hacer clic en "Aplicar Filtros"
3. La lista se actualiza con los resultados

## Solución de Problemas

### Error de Conexión con Backend
- Verificar que el backend esté ejecutándose en puerto 8080
- Revisar la consola del navegador para errores CORS
- Verificar la configuración del proxy en package.json

### Error de Dependencias
```bash
# Limpiar cache de npm
npm cache clean --force

# Eliminar node_modules y reinstalar
rm -rf node_modules package-lock.json
npm install
```

### Error de Puerto
Si el puerto 3000 está ocupado, React automáticamente sugerirá usar otro puerto.

## Desarrollo

### Estructura de Commits
```
feat: nueva funcionalidad
fix: corrección de bug
docs: documentación
style: cambios de estilo
refactor: refactorización de código
test: pruebas
chore: tareas de mantenimiento
```

### Linting
El proyecto usa ESLint configurado para React. Para verificar el código:

```bash
npm run lint
```

### Build de Producción
```bash
npm run build
```

Esto creará una carpeta `build` con la aplicación optimizada para producción.

## Contribución

1. Crear una rama para tu feature
2. Hacer commits descriptivos
3. Ejecutar pruebas antes de hacer push
4. Crear un Pull Request con descripción detallada

## Licencia

Este proyecto está bajo la Licencia MIT.
