package com.transaction.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Result of a payment processing operation.
 * Contains information about how many transactions were paid and remaining amount.
 * 
 * @author Transaction Management System
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResult {
    
    /**
     * Number of transactions that were successfully paid.
     */
    private int transaccionesPagadas;
    
    /**
     * Remaining amount after payment processing.
     */
    private BigDecimal montoRestante;
    
    /**
     * Original amount that was attempted to pay.
     */
    private BigDecimal montoInicial;
    
    /**
     * Gets a user-friendly message describing the payment result.
     * 
     * @return Formatted message about the payment result
     */
    public String getMensaje() {
        if (transaccionesPagadas == 0) {
            return "No se pudo pagar ninguna transacción. El monto $" + montoInicial + 
                   " no es suficiente para cubrir completamente la transacción más antigua pendiente.";
        } else if (transaccionesPagadas == 1) {
            return "Se pagó 1 transacción exitosamente. Monto restante: $" + montoRestante;
        } else {
            return "Se pagaron " + transaccionesPagadas + " transacciones exitosamente. Monto restante: $" + montoRestante;
        }
    }
} 