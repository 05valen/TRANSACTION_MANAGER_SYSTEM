package com.transaction.service;


import com.transaction.dto.TransaccionCreateDTO;
import com.transaction.dto.TransaccionDTO;
import com.transaction.entity.EstadoTransaccion;
import com.transaction.entity.Transaccion;
import com.transaction.repository.TransaccionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service layer for transaction business logic.
 * <p>
 * Handles CRUD operations, filtering, and payment processing with business rules enforcement.
 * <ul>
 *   <li>Only transactions in PENDIENTE state can be edited or deleted.</li>
 *   <li>Payments are applied in chronological order and only if the amount covers the full transaction.</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
public class TransaccionService {
    private final TransaccionRepository transaccionRepository;

    /**
     * Retrieves a list of transactions filtered by name, date, and state.
     *
     * @param nombre Optional name filter (partial match, case-insensitive)
     * @param fecha  Optional exact date filter
     * @param estado Optional state filter
     * @return List of matching transactions as DTOs
     */
    public List<TransaccionDTO> listar(String nombre, LocalDate fecha, EstadoTransaccion estado) {
        return transaccionRepository.findByFilters(nombre, fecha, estado)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    /**
     * Creates a new transaction with state PENDIENTE.
     *
     * @param dto Data for the new transaction
     * @return The created transaction as DTO
     */
    public TransaccionDTO crear(TransaccionCreateDTO dto) {
        Transaccion t = Transaccion.builder()
                .nombre(dto.getNombre())
                .fecha(dto.getFecha())
                .valor(dto.getValor())
                .estado(EstadoTransaccion.PENDIENTE)
                .build();
        return toDTO(transaccionRepository.save(t));
    }

    /**
     * Updates an existing transaction if it is not paid.
     *
     * @param id  Transaction ID
     * @param dto New data for the transaction
     * @return The updated transaction as DTO
     * @throws IllegalArgumentException if transaction not found
     * @throws IllegalStateException    if transaction is already paid
     */
    public TransaccionDTO editar(Long id, TransaccionCreateDTO dto) {
        Transaccion t = transaccionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Transacción no encontrada"));
        if (t.getEstado() == EstadoTransaccion.PAGADO) {
            throw new IllegalStateException("No se puede editar una transacción pagada");
        }
        t.setNombre(dto.getNombre());
        t.setFecha(dto.getFecha());
        t.setValor(dto.getValor());
        return toDTO(transaccionRepository.save(t));
    }

    /**
     * Deletes a transaction if it is not paid.
     *
     * @param id Transaction ID
     * @throws IllegalArgumentException if transaction not found
     * @throws IllegalStateException    if transaction is already paid
     */
    public void eliminar(Long id) {
        Transaccion t = transaccionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Transacción no encontrada"));
        if (t.getEstado() == EstadoTransaccion.PAGADO) {
            throw new IllegalStateException("No se puede eliminar una transacción pagada");
        }
        transaccionRepository.deleteById(id);
    }

    /**
     * Processes a payment, marking transactions as paid in chronological order if the amount covers them fully.
     * 
     * Lógica de pago por lote:
     * - Se pagan transacciones en orden de fecha (más antigua primero)
     * - Solo se paga si el monto cubre completamente la transacción
     * - Si el monto no alcanza para la siguiente, se detiene
     * - No se paga por ID, sino por orden y monto, como lo especifica el enunciado de la prueba técnica
     *
     * @param monto Amount to pay
     * @return PaymentResult containing information about the payment process
     */
    @Transactional
    public PaymentResult pagar(BigDecimal monto) {
        List<Transaccion> pendientes = transaccionRepository.findByEstadoOrderByFechaAsc(EstadoTransaccion.PENDIENTE);
        int transaccionesPagadas = 0;
        BigDecimal montoInicial = monto;
        
        for (Transaccion t : pendientes) {
            if (monto.compareTo(t.getValor()) >= 0) {
                t.setEstado(EstadoTransaccion.PAGADO);
                transaccionRepository.save(t);
                monto = monto.subtract(t.getValor());
                transaccionesPagadas++;
            } else {
                break; // No paga si no cubre la transacción completa
            }
        }
        
        return new PaymentResult(transaccionesPagadas, monto, montoInicial);
    }

    /**
     * Retrieves a transaction by its ID.
     *
     * @param id Transaction ID
     * @return Optional containing the transaction as DTO if found, empty otherwise
     */
    public Optional<TransaccionDTO> obtenerPorId(Long id) {
        return transaccionRepository.findById(id).map(this::toDTO);
    }

    /**
     * Converts a Transaccion entity to its DTO representation.
     *
     * @param t Transaccion entity
     * @return TransaccionDTO
     */
    private TransaccionDTO toDTO(Transaccion t) {
        TransaccionDTO dto = new TransaccionDTO();
        dto.setId(t.getId());
        dto.setNombre(t.getNombre());
        dto.setFecha(t.getFecha());
        dto.setValor(t.getValor());
        dto.setEstado(t.getEstado());
        return dto;
    }
}

